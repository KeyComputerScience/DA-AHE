/*
 * Copyright (c) 2008, Swedish Institute of Computer Science
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * This file is part of the Contiki operating system.
 *
 */

/**
 * \file
 *         Coffee architecture-dependent header for the srf06-cc2650 sensortag platform.
 * \author
 *         Dongda Lee <dongdongbhbh@gmail.com>
 */

#ifndef CFS_COFFEE_ARCH_H
#define CFS_COFFEE_ARCH_H

#include "contiki-conf.h"
#include "dev/xmem.h"

/*
 * MX25R8035F Memory Organization
 * The memory is organized as:
 * 8Mbit = 1048576 bytes (8 bits each)
 * 256 sectors (32 Kbits, 4096 bytes each)
 * 4096 pages (256 bytes each).
 * Each page can be individually programmed (bits are programmed from 1 to 0).
 * The device is sector or bulk erasable (bits are erased from 0 to 1) but not
 * page erasable
 */
#define COFFEE_XMEM_TOTAL_SIZE_KB       1024UL  /* Total size of the External Flash Memory in the Z1 */

/* Coffee configuration parameters. */
#define COFFEE_SECTOR_SIZE      4096UL
#define COFFEE_PAGE_SIZE        256UL
#define COFFEE_START            0UL             /* COFFEE_SECTOR_SIZE */
#define COFFEE_SIZE             (COFFEE_XMEM_TOTAL_SIZE_KB * 1024UL - COFFEE_START)
#define COFFEE_NAME_LENGTH      16
#define COFFEE_MAX_OPEN_FILES   6
#define COFFEE_FD_SET_SIZE      8
#define COFFEE_LOG_TABLE_LIMIT  256
#define COFFEE_DYN_SIZE         2 * 1024
#define COFFEE_LOG_SIZE         1024

#define COFFEE_MICRO_LOGS       1

/* Flash operations. */
#define COFFEE_WRITE(buf, size, offset) \
  xmem_pwrite((char *)(buf), (size), COFFEE_START + (offset))

#define COFFEE_READ(buf, size, offset) \
  xmem_pread((char *)(buf), (size), COFFEE_START + (offset))

#define COFFEE_ERASE(sector) \
  xmem_erase(COFFEE_SECTOR_SIZE, COFFEE_START + (sector) * COFFEE_SECTOR_SIZE)

/* Coffee types. */
typedef int16_t coffee_page_t;

#endif /* !COFFEE_ARCH_H */
